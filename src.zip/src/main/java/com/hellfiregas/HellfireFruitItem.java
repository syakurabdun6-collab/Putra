package com.hellfiregas;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class HellfireFruitItem extends Item {
    private static final int TRANSFORM_DURATION = 20 * 45;
    private static final int COOLDOWN_TICKS = 20 * 12;

    public HellfireFruitItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide()) {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, TRANSFORM_DURATION, 0));
            player.addEffect(new MobEffectInstance(MobEffects.SPEED, TRANSFORM_DURATION, 1));
            player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, TRANSFORM_DURATION, 1));
            player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
        }
        if (level.isClientSide()) {
            for (int i=0;i<28;i++) {
                double a=(Math.PI*2*i)/28.0;
                level.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                    player.getX()+Math.cos(a)*1.15, player.getY()+0.7,
                    player.getZ()+Math.sin(a)*1.15, 0.0, 0.045, 0.0);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
