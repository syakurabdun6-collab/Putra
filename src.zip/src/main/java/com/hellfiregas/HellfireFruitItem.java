
package com.hellfiregas;

import net.minecraft.core.Identifier;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public final class HellfireFruitItem extends Item {

    private static final int TRANSFORM_TICKS = 20 * 45;
    private static final int COOLDOWN_TICKS = 20 * 12;

    private static final Identifier COOLDOWN_ID =
            Identifier.fromNamespaceAndPath("hellfiregas", "hellfire_fruit");

    public HellfireFruitItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {

        if (player.getCooldowns().isOnCooldown(COOLDOWN_ID)) {
            return InteractionResult.FAIL;
        }

        if (level.isClientSide()) {

            for (int ring = 0; ring < 3; ring++) {
                double radius = 0.75 + ring * 0.38;
                double height = 0.12 + ring * 0.48;

                for (int i = 0; i < 24; i++) {
                    double angle = Math.PI * 2.0 * i / 24.0;

                    double x = player.getX() + Math.cos(angle) * radius;
                    double z = player.getZ() + Math.sin(angle) * radius;

                    level.addParticle(
                            ring == 1
                                    ? ParticleTypes.SOUL_FIRE_FLAME
                                    : ParticleTypes.FLAME,
                            x,
                            player.getY() + height,
                            z,
                            0.0,
                            0.035,
                            0.0
                    );
                }
            }

        } else {

            player.addEffect(new MobEffectInstance(
                    MobEffects.FIRE_RESISTANCE, TRANSFORM_TICKS, 0));

            player.addEffect(new MobEffectInstance(
                    MobEffects.SPEED, TRANSFORM_TICKS, 0));

            player.addEffect(new MobEffectInstance(
                    MobEffects.ABSORPTION, TRANSFORM_TICKS, 0));

            player.getCooldowns().addCooldown(
                    COOLDOWN_ID, COOLDOWN_TICKS);
        }

        return InteractionResult.SUCCESS;
    }
}
