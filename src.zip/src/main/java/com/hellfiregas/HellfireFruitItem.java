
package com.hellfiregas;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class HellfireFruitItem extends Item {

    private static final int TRANSFORM_DURATION = 20 * 45;
    private static final int COOLDOWN_TICKS = 20 * 12;

    public HellfireFruitItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {

        ItemStack stack = player.getItemInHand(hand);

        if (player.getCooldowns().isOnCooldown(stack)) {
            return InteractionResult.SUCCESS;
        }

        if (!level.isClientSide()) {

            player.addEffect(new MobEffectInstance(
                    MobEffects.FIRE_RESISTANCE,
                    TRANSFORM_DURATION,
                    0
            ));

            player.addEffect(new MobEffectInstance(
                    MobEffects.SPEED,
                    TRANSFORM_DURATION,
                    0
            ));

            player.addEffect(new MobEffectInstance(
                    MobEffects.ABSORPTION,
                    TRANSFORM_DURATION,
                    0
            ));

            player.getCooldowns().addCooldown(
                    stack,
                    COOLDOWN_TICKS
            );
        }

        if (level.isClientSide()) {
            for (int i = 0; i < 20; i++) {
                double angle = (Math.PI * 2.0 * i) / 20.0;

                double x = player.getX() + Math.cos(angle) * 1.2;
                double z = player.getZ() + Math.sin(angle) * 1.2;

                level.addParticle(
                        ParticleTypes.SOUL_FIRE_FLAME,
                        x,
                        player.getY() + 0.8,
                        z,
                        0.0,
                        0.04,
                        0.0
                );

                level.addParticle(
                        ParticleTypes.FLAME,
                        x,
                        player.getY() + 0.5,
                        z,
                        0.0,
                        0.03,
                        0.0
                );
            }
        }

        return InteractionResult.SUCCESS;
    }
}
