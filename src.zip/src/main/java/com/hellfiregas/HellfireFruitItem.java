package com.hellfiregas;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public final class HellfireFruitItem extends Item {
    private static final int TRANSFORM_TICKS = 20 * 45;
    private static final int COOLDOWN_TICKS = 20 * 12;

    public HellfireFruitItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!player.getCooldowns().isOnCooldown(this)) {
            if (level.isClientSide()) {
                spawnActivationBurst(level, player);
            } else {
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, TRANSFORM_TICKS, 0));
                player.addEffect(new MobEffectInstance(MobEffects.SPEED, TRANSFORM_TICKS, 0));
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, TRANSFORM_TICKS, 0));
                player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            }
        }
        return InteractionResult.SUCCESS;
    }

    private static void spawnActivationBurst(Level level, Player player) {
        double px = player.getX();
        double py = player.getY();
        double pz = player.getZ();

        for (int ring = 0; ring < 3; ring++) {
            double radius = 0.75 + ring * 0.38;
            double height = 0.12 + ring * 0.48;
            int points = 24;
            for (int i = 0; i < points; i++) {
                double angle = (Math.PI * 2.0 * i) / points;
                double x = px + Math.cos(angle) * radius;
                double z = pz + Math.sin(angle) * radius;
                level.addParticle(
                        ring == 1 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME,
                        x, py + height, z, 0.0, 0.025 + ring * 0.01, 0.0
                );
            }
        }

        for (int i = 0; i < 18; i++) {
            double angle = (Math.PI * 2.0 * i) / 18.0;
            double x = px + Math.cos(angle) * 0.55;
            double z = pz + Math.sin(angle) * 0.55;
            level.addParticle(ParticleTypes.LAVA, x, py + 0.9, z, 0.0, 0.04, 0.0);
        }
    }
}
