package com.hellfiregas;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public final class HellfireGas implements ModInitializer {
    public static final String MOD_ID = "hellfiregas";

    public static final Item HELLFIRE_FRUIT = register(
            "hellfire_fruit",
            HellfireFruitItem::new,
            new Item.Properties().stacksTo(1)
    );

    private static Item register(String name,
                                 java.util.function.Function<Item.Properties, Item> factory,
                                 Item.Properties properties) {
        ResourceKey<Item> key = ResourceKey.create(
                Registries.ITEM,
                Identifier.fromNamespaceAndPath(MOD_ID, name)
        );
        Item item = factory.apply(properties.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    @Override
    public void onInitialize() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS)
                .register(tab -> tab.accept(HELLFIRE_FRUIT));
        System.out.println("Hellfire Gas loaded!");
    }
}
