package com.hellfiregas.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Hellfire Gas client visuals.
 *
 * M1 is visual-only in this first pass: Minecraft's normal attack still
 * handles hit detection and damage. Four successive attack presses produce
 * four different particle bursts. No skill keys or skill HUD are registered.
 */
public final class HellfireGasClient implements ClientModInitializer {
    private static int tick;
    private static boolean attackWasDown;
    private static int comboStep;
    private static int comboTimer;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Player player = client.player;
            if (player == null || client.level == null) {
                attackWasDown = false;
                comboStep = 0;
                comboTimer = 0;
                return;
            }

            tick++;

            boolean transformed = player.hasEffect(MobEffects.FIRE_RESISTANCE);
            boolean attackDown = client.options.keyAttack.isDown();

            // Count each fresh M1 press as one beat in the four-hit combo.
            if (transformed && attackDown && !attackWasDown) {
                if (comboTimer <= 0) {
                    comboStep = 1;
                } else {
                    comboStep = (comboStep % 4) + 1;
                }
                comboTimer = 18;
                spawnPunchEffect(client.level, player, comboStep);
            }

            attackWasDown = attackDown;

            if (comboTimer > 0) {
                comboTimer--;
            } else {
                comboStep = 0;
            }

            if (!transformed) {
                return;
            }

            // Alternating light-green gas and deep-green hellfire orbit layers.
            for (int i = 0; i < 4; i++) {
                double direction = (i % 2 == 0) ? 1.0 : -1.0;
                double angle = tick * 0.105 * direction + i * (Math.PI / 2.0);
                double radius = (i < 2) ? 0.76 : 1.02;
                double height = (i < 2) ? 0.42 + i * 0.34 : 1.08 + (i - 2) * 0.34;
                double x = player.getX() + Math.cos(angle) * radius;
                double z = player.getZ() + Math.sin(angle) * radius;

                if (i % 2 == 0) {
                    client.level.addParticle(ParticleTypes.HAPPY_VILLAGER,
                            x, player.getY() + height, z,
                            0.0, 0.018, 0.0);
                    client.level.addParticle(ParticleTypes.COMPOSTER,
                            x, player.getY() + height + 0.06, z,
                            Math.cos(angle) * 0.01, 0.025, Math.sin(angle) * 0.01);
                } else {
                    client.level.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                            x, player.getY() + height, z,
                            Math.cos(angle) * 0.008, 0.03, Math.sin(angle) * 0.008);
                    client.level.addParticle(ParticleTypes.SMOKE,
                            x, player.getY() + height, z,
                            0.0, 0.012, 0.0);
                }
            }
        });
    }

    private static void spawnPunchEffect(net.minecraft.client.multiplayer.ClientLevel level,
                                         Player player, int stage) {
        Vec3 look = player.getLookAngle().normalize();
        Vec3 side = new Vec3(-look.z, 0.0, look.x).normalize();
        double sideOffset = (stage == 1 || stage == 3) ? 0.22 : -0.22;
        double reach = stage == 4 ? 0.98 : 0.78;

        double x = player.getX() + look.x * reach + side.x * sideOffset;
        double y = player.getY() + player.getBbHeight() * 0.62;
        double z = player.getZ() + look.z * reach + side.z * sideOffset;

        int particles = stage == 4 ? 22 : 12;
        for (int i = 0; i < particles; i++) {
            double dx = (level.random.nextDouble() - 0.5) * (stage == 4 ? 0.62 : 0.42);
            double dy = (level.random.nextDouble() - 0.5) * (stage == 4 ? 0.62 : 0.42);
            double dz = (level.random.nextDouble() - 0.5) * (stage == 4 ? 0.62 : 0.42);

            level.addParticle(ParticleTypes.CRIT, x, y, z, dx, dy, dz);
            level.addParticle(ParticleTypes.COMPOSTER,
                    x + dx, y + dy, z + dz,
                    dx * 0.25, 0.025 + dy * 0.15, dz * 0.25);
        }

        // The fourth M1 beat has a larger finishing ring and stronger flame burst.
        if (stage == 4) {
            for (int i = 0; i < 12; i++) {
                double angle = Math.PI * 2.0 * i / 12.0;
                level.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                        x, y, z,
                        Math.cos(angle) * 0.14, 0.045, Math.sin(angle) * 0.14);
            }
            level.addParticle(ParticleTypes.EXPLOSION,
                    x, y, z, 0.0, 0.0, 0.0);
        }
    }
}
