package com.hellfiregas.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffects;

public final class HellfireGasClient implements ClientModInitializer {
    private static int tick = 0;
    @Override public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Player p=client.player;
            if (p==null || client.level==null || !p.hasEffect(MobEffects.FIRE_RESISTANCE)) return;
            tick++;
            for (int ring=0;ring<3;ring++) {
                double a=tick*0.13+ring*(Math.PI*2/3.0);
                double r=ring==1?1.0:0.72;
                double h=0.2+ring*0.55;
                client.level.addParticle(ring==1?ParticleTypes.SOUL_FIRE_FLAME:ParticleTypes.FLAME,
                    p.getX()+Math.cos(a)*r,p.getY()+h,p.getZ()+Math.sin(a)*r,
                    Math.cos(a)*0.012,0.035,Math.sin(a)*0.012);
            }
        });
    }
}
