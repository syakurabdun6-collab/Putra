package com.hellfiregas.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffects;

public final class HellfireGasClient implements ClientModInitializer {
    private static int animationTick = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Player player = client.player;
            if (player == null || client.level == null) return;
            if (!player.hasEffect(MobEffects.FIRE_RESISTANCE)) return;

            animationTick++;
            spawnOrbitingHellfire(player);
        });
        System.out.println("Hellfire Gas client visuals loaded!");
    }

    private static void spawnOrbitingHellfire(Player player) {
        double baseAngle = animationTick * 0.16;
        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();

        for (int ring = 0; ring < 3; ring++) {
            double angle = baseAngle + ring * (Math.PI * 2.0 / 3.0);
            double radius = ring == 1 ? 1.02 : 0.78;
            double height = ring == 0 ? 0.18 : (ring == 1 ? 0.78 : 1.38);
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            player.level().addParticle(
                    ring == 1 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME,
                    px, y + height, pz,
                    Math.cos(angle) * 0.015, 0.035, Math.sin(angle) * 0.015
            );
        }

        if (animationTick % 3 == 0) {
            double angle = baseAngle * 1.7;
            double px = x + Math.cos(angle) * 0.42;
            double pz = z + Math.sin(angle) * 0.42;
            player.level().addParticle(ParticleTypes.FLAME, px, y + 1.05, pz, 0.0, 0.055, 0.0);
        }
    }
}
